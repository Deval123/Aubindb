<?php
/**
 * Created by PhpStorm.
 * User: devalere
 * Date: 03/03/2019
 * Time: 03:27
 */


header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

require_once("conn.php");

include "config.php";
$datetime = date("Y-m-d H:i:s");
$data = array();
$query = mysqli_query($mysqli, "SELECT * FROM pharmacists WHERE login = 'Tiogiuyhjkeng'  and password = 'anderson123'  ORDER BY id DESC");

while ($row = mysqli_fetch_array($query)) {
    $data[] = array(
        'id' => $row['id'],
        'nom' => $row['nom'],
        'prenom' => $row['prenom'],
        'sexe' => $row['sexe'],
        'tel' => $row['tel'],
        'email' => $row['email'],
        'password' => $row['password'],
        'images' => $row['images'],
        'login' => $row['login'],
        'datecreate' => $row['datecreate']
    );
}


if ($query) {
    $count = mysqli_num_rows($query);

    if ($count > 0) {
        $result = json_encode(array('success' => true, 'result' => $data));
    } else {
        $result = json_encode(array('success' => false));

    }
}

echo $result;
